/*#include <stdio.h>
int main()
{
int a;
printf("\n Enter the value of a : ");
scanf("%d", &a);
if(a%2==0)
printf("\n %d is even\n", a);
else
printf("\n %d is odd\n", a);
return 0;
}
*/
//hackerrank check code
#include<stdio.h>
int main()
{
    int i;
    scanf("%d",&i);
        if(i%2==0)
            printf("Not Weird",i);
        else
            printf("Weird",i);
return 0;
}
