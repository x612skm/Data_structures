#include <stdio.h>
int main()
{
int x=1;
if (x>0) 
x++;
printf("\n x = %d", x);
return 0;
}
